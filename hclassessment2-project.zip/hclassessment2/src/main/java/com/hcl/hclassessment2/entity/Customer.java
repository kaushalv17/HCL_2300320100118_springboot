package com.hcl.hclassessment2.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.util.*;
@Entity @Table(name="customers")
public class Customer {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long customerId;
 private String customerName;
 @Column(unique=true, nullable=false) private String email;
 private String password;
 private String mobile;
 private String city;
 @JsonIgnore @OneToOne(mappedBy="customer", cascade=CascadeType.ALL) private Cart cart;
 @JsonIgnore @OneToMany(mappedBy="customer") private List<CustomerOrder> orders=new ArrayList<>();
 public Customer(){}
 public Long getCustomerId(){return customerId;} public void setCustomerId(Long v){customerId=v;}
 public String getCustomerName(){return customerName;} public void setCustomerName(String v){customerName=v;}
 public String getEmail(){return email;} public void setEmail(String v){email=v;}
 public String getPassword(){return password;} public void setPassword(String v){password=v;}
 public String getMobile(){return mobile;} public void setMobile(String v){mobile=v;}
 public String getCity(){return city;} public void setCity(String v){city=v;}
 public Cart getCart(){return cart;} public void setCart(Cart v){cart=v;}
 public List<CustomerOrder> getOrders(){return orders;} public void setOrders(List<CustomerOrder> v){orders=v;}
}
