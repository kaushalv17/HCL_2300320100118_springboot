package com.hcl.hclassessment2.service;
import com.hcl.hclassessment2.entity.*;
import com.hcl.hclassessment2.repository.*;
import com.hcl.hclassessment2.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate; import java.util.List;
@Service
public class CartService {
 private final CartRepository carts; private final CartItemRepository items;
 private final CustomerRepository customers; private final ProductRepository products;
 public CartService(CartRepository carts,CartItemRepository items,CustomerRepository customers,ProductRepository products){
  this.carts=carts;this.items=items;this.customers=customers;this.products=products;
 }
 @Transactional
 public Cart cart(Long customerId){
  Customer customer=customers.findById(customerId).orElseThrow(()->new ResourceNotFoundException("Customer not found: "+customerId));
  return carts.findByCustomerCustomerId(customerId).orElseGet(()->{
   Cart c=new Cart();c.setCustomer(customer);c.setCreatedDate(LocalDate.now());return carts.save(c);
  });
 }
 @Transactional
 public CartItem add(Long customerId,Long productId,Integer quantity){
  if(quantity==null||quantity<=0)throw new IllegalArgumentException("Quantity must be positive");
  Cart c=cart(customerId);Product p=products.findById(productId).orElseThrow(()->new ResourceNotFoundException("Product not found: "+productId));
  CartItem item=items.findByCartCartIdAndProductProductId(c.getCartId(),productId).orElseGet(CartItem::new);
  int total=(item.getQuantity()==null?0:item.getQuantity())+quantity;
  if(p.getQuantity()<total)throw new IllegalArgumentException("Insufficient stock");
  item.setCart(c);item.setProduct(p);item.setQuantity(total);item.setPrice(p.getPrice());return items.save(item);
 }
 public List<CartItem> list(Long customerId){Cart c=cart(customerId);return items.findByCartCartId(c.getCartId());}
 @Transactional
 public CartItem update(Long customerId,Long productId,Integer quantity){
  if(quantity==null||quantity<=0)throw new IllegalArgumentException("Quantity must be positive");
  Cart c=cart(customerId);CartItem i=items.findByCartCartIdAndProductProductId(c.getCartId(),productId)
   .orElseThrow(()->new ResourceNotFoundException("Cart item not found"));
  if(i.getProduct().getQuantity()<quantity)throw new IllegalArgumentException("Insufficient stock");
  i.setQuantity(quantity);i.setPrice(i.getProduct().getPrice());return items.save(i);
 }
 @Transactional
 public void remove(Long customerId,Long productId){
  Cart c=cart(customerId);CartItem i=items.findByCartCartIdAndProductProductId(c.getCartId(),productId)
   .orElseThrow(()->new ResourceNotFoundException("Cart item not found"));items.delete(i);
 }
}
