package com.hcl.hclassessment2.controller;
import com.hcl.hclassessment2.entity.CustomerOrder; import com.hcl.hclassessment2.service.OrderService;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/api")
public class OrderController {
 private final OrderService service; public OrderController(OrderService service){this.service=service;}
 @PostMapping("/customers/{customerId}/orders") @ResponseStatus(HttpStatus.CREATED)
 public CustomerOrder place(@PathVariable Long customerId){return service.place(customerId);}
 @GetMapping("/customers/{customerId}/orders") public List<CustomerOrder> history(@PathVariable Long customerId){return service.history(customerId);}
 @GetMapping("/orders/{orderId}") public CustomerOrder one(@PathVariable Long orderId){return service.one(orderId);}
 @PutMapping("/orders/{orderId}/cancel") public CustomerOrder cancel(@PathVariable Long orderId){return service.cancel(orderId);}
}
