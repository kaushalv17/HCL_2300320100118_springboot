package com.hcl.hclassessment2.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
@Entity @Table(name="order_items")
public class OrderItem {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long orderItemId;
 @JsonIgnore @ManyToOne @JoinColumn(name="order_id",nullable=false) private CustomerOrder customerOrder;
 @ManyToOne @JoinColumn(name="product_id",nullable=false) private Product product;
 private Integer quantity; private Double price;
 public OrderItem(){}
 public Long getOrderItemId(){return orderItemId;} public void setOrderItemId(Long v){orderItemId=v;}
 public CustomerOrder getCustomerOrder(){return customerOrder;} public void setCustomerOrder(CustomerOrder v){customerOrder=v;}
 public Product getProduct(){return product;} public void setProduct(Product v){product=v;}
 public Integer getQuantity(){return quantity;} public void setQuantity(Integer v){quantity=v;}
 public Double getPrice(){return price;} public void setPrice(Double v){price=v;}
}
