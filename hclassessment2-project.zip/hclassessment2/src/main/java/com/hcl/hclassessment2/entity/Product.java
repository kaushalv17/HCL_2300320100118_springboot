package com.hcl.hclassessment2.entity;
import jakarta.persistence.*;
@Entity @Table(name="products")
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long productId;
 private String productName; private String description; private Double price; private Integer quantity; private String category;
 public Product(){}
 public Long getProductId(){return productId;} public void setProductId(Long v){productId=v;}
 public String getProductName(){return productName;} public void setProductName(String v){productName=v;}
 public String getDescription(){return description;} public void setDescription(String v){description=v;}
 public Double getPrice(){return price;} public void setPrice(Double v){price=v;}
 public Integer getQuantity(){return quantity;} public void setQuantity(Integer v){quantity=v;}
 public String getCategory(){return category;} public void setCategory(String v){category=v;}
}
