package com.hcl.hclassessment2.entity;
import jakarta.persistence.*;
import java.time.LocalDateTime; import java.util.*;
@Entity @Table(name="customer_orders")
public class CustomerOrder {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long orderId;
 @ManyToOne @JoinColumn(name="customer_id",nullable=false) private Customer customer;
 private LocalDateTime orderDate; private Double totalAmount; private String orderStatus;
 @OneToMany(mappedBy="customerOrder",cascade=CascadeType.ALL,orphanRemoval=true) private List<OrderItem> items=new ArrayList<>();
 public CustomerOrder(){}
 public Long getOrderId(){return orderId;} public void setOrderId(Long v){orderId=v;}
 public Customer getCustomer(){return customer;} public void setCustomer(Customer v){customer=v;}
 public LocalDateTime getOrderDate(){return orderDate;} public void setOrderDate(LocalDateTime v){orderDate=v;}
 public Double getTotalAmount(){return totalAmount;} public void setTotalAmount(Double v){totalAmount=v;}
 public String getOrderStatus(){return orderStatus;} public void setOrderStatus(String v){orderStatus=v;}
 public List<OrderItem> getItems(){return items;} public void setItems(List<OrderItem> v){items=v;}
}
