package com.hcl.hclassessment2.controller;
import com.hcl.hclassessment2.entity.Customer; import com.hcl.hclassessment2.service.CustomerService;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/api/customers")
public class CustomerController {
 private final CustomerService service; public CustomerController(CustomerService service){this.service=service;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Customer create(@RequestBody Customer c){return service.create(c);}
 @GetMapping public List<Customer> all(){return service.all();}
 @GetMapping("/{id}") public Customer one(@PathVariable Long id){return service.one(id);}
 @PutMapping("/{id}") public Customer update(@PathVariable Long id,@RequestBody Customer c){return service.update(id,c);}
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id){service.delete(id);}
}
