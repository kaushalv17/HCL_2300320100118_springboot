package com.hcl.hclassessment2.repository;
import com.hcl.hclassessment2.entity.OrderItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {  }
