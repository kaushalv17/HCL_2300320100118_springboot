package com.hcl.hclassessment2.service;
import com.hcl.hclassessment2.entity.Customer;
import com.hcl.hclassessment2.repository.CustomerRepository;
import com.hcl.hclassessment2.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class CustomerService {
 private final CustomerRepository repo;
 public CustomerService(CustomerRepository repo){this.repo=repo;}
 public Customer create(Customer c){
  if(c.getEmail()==null||c.getEmail().isBlank()) throw new IllegalArgumentException("Email is required");
  if(repo.findByEmail(c.getEmail()).isPresent()) throw new IllegalArgumentException("Email already registered");
  return repo.save(c);
 }
 public List<Customer> all(){return repo.findAll();}
 public Customer one(Long id){return repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Customer not found: "+id));}
 public Customer update(Long id,Customer input){
  Customer c=one(id); c.setCustomerName(input.getCustomerName()); c.setEmail(input.getEmail());
  c.setPassword(input.getPassword()); c.setMobile(input.getMobile()); c.setCity(input.getCity()); return repo.save(c);
 }
 public void delete(Long id){repo.delete(one(id));}
}
