package com.hcl.hclassessment2.controller;
import com.hcl.hclassessment2.entity.Product; import com.hcl.hclassessment2.service.ProductService;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.List;
@RestController @RequestMapping("/api/products")
public class ProductController {
 private final ProductService service; public ProductController(ProductService service){this.service=service;}
 @PostMapping @ResponseStatus(HttpStatus.CREATED) public Product create(@RequestBody Product p){return service.create(p);}
 @GetMapping public List<Product> all(){return service.all();}
 @GetMapping("/{id}") public Product one(@PathVariable Long id){return service.one(id);}
 @PutMapping("/{id}") public Product update(@PathVariable Long id,@RequestBody Product p){return service.update(id,p);}
 @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id){service.delete(id);}
}
