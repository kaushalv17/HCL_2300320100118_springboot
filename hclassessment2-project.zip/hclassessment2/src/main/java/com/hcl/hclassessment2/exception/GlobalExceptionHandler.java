package com.hcl.hclassessment2.exception;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime; import java.util.Map;
@RestControllerAdvice
public class GlobalExceptionHandler {
 @ExceptionHandler(ResourceNotFoundException.class)
 public ResponseEntity<Map<String,Object>> notFound(ResourceNotFoundException e){
  return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("timestamp",LocalDateTime.now().toString(),"status",404,"message",e.getMessage()));
 }
 @ExceptionHandler(IllegalArgumentException.class)
 public ResponseEntity<Map<String,Object>> badRequest(IllegalArgumentException e){
  return ResponseEntity.badRequest().body(Map.of("timestamp",LocalDateTime.now().toString(),"status",400,"message",e.getMessage()));
 }
 @ExceptionHandler(Exception.class)
 public ResponseEntity<Map<String,Object>> serverError(Exception e){
  return ResponseEntity.status(500).body(Map.of("timestamp",LocalDateTime.now().toString(),"status",500,"message",e.getMessage()==null?"Unexpected error":e.getMessage()));
 }
}
