package com.hcl.hclassessment2.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import java.time.LocalDate; import java.util.*;
@Entity @Table(name="carts")
public class Cart {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long cartId;
 @OneToOne @JoinColumn(name="customer_id", unique=true) private Customer customer;
 private LocalDate createdDate;
 @JsonIgnore @OneToMany(mappedBy="cart",cascade=CascadeType.ALL,orphanRemoval=true) private List<CartItem> items=new ArrayList<>();
 public Cart(){}
 public Long getCartId(){return cartId;} public void setCartId(Long v){cartId=v;}
 public Customer getCustomer(){return customer;} public void setCustomer(Customer v){customer=v;}
 public LocalDate getCreatedDate(){return createdDate;} public void setCreatedDate(LocalDate v){createdDate=v;}
 public List<CartItem> getItems(){return items;} public void setItems(List<CartItem> v){items=v;}
}
