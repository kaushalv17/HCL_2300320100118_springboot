package com.hcl.hclassessment2.service;
import com.hcl.hclassessment2.entity.Product;
import com.hcl.hclassessment2.repository.ProductRepository;
import com.hcl.hclassessment2.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service; import java.util.List;
@Service
public class ProductService {
 private final ProductRepository repo;
 public ProductService(ProductRepository repo){this.repo=repo;}
 private void validate(Product p){
  if(p.getPrice()==null||p.getPrice()<0) throw new IllegalArgumentException("Price must be zero or greater");
  if(p.getQuantity()==null||p.getQuantity()<0) throw new IllegalArgumentException("Quantity must be zero or greater");
 }
 public Product create(Product p){validate(p);return repo.save(p);}
 public List<Product> all(){return repo.findAll();}
 public Product one(Long id){return repo.findById(id).orElseThrow(()->new ResourceNotFoundException("Product not found: "+id));}
 public Product update(Long id,Product p){
  Product old=one(id); old.setProductName(p.getProductName()); old.setDescription(p.getDescription());
  old.setPrice(p.getPrice()); old.setQuantity(p.getQuantity()); old.setCategory(p.getCategory()); validate(old); return repo.save(old);
 }
 public void delete(Long id){repo.delete(one(id));}
}
