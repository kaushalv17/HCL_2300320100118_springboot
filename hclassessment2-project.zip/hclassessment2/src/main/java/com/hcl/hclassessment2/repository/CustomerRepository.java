package com.hcl.hclassessment2.repository;
import com.hcl.hclassessment2.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface CustomerRepository extends JpaRepository<Customer, Long> { Optional<Customer> findByEmail(String email); }
