package com.hcl.hclassessment2.entity;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
@Entity @Table(name="cart_items")
public class CartItem {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private Long cartItemId;
 @JsonIgnore @ManyToOne @JoinColumn(name="cart_id") private Cart cart;
 @ManyToOne @JoinColumn(name="product_id",nullable=false) private Product product;
 private Integer quantity; private Double price;
 public CartItem(){}
 public Long getCartItemId(){return cartItemId;} public void setCartItemId(Long v){cartItemId=v;}
 public Cart getCart(){return cart;} public void setCart(Cart v){cart=v;}
 public Product getProduct(){return product;} public void setProduct(Product v){product=v;}
 public Integer getQuantity(){return quantity;} public void setQuantity(Integer v){quantity=v;}
 public Double getPrice(){return price;} public void setPrice(Double v){price=v;}
}
