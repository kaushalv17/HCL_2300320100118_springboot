package com.hcl.hclassessment2.controller;
import com.hcl.hclassessment2.entity.*; import com.hcl.hclassessment2.service.CartService;
import org.springframework.http.HttpStatus; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/customers/{customerId}/cart")
public class CartController {
 private final CartService service; public CartController(CartService service){this.service=service;}
 @GetMapping public Cart get(@PathVariable Long customerId){return service.cart(customerId);}
 @GetMapping("/items") public List<CartItem> list(@PathVariable Long customerId){return service.list(customerId);}
 @PostMapping("/items") @ResponseStatus(HttpStatus.CREATED)
 public CartItem add(@PathVariable Long customerId,@RequestBody Map<String,Object> body){
  return service.add(customerId,Long.valueOf(body.get("productId").toString()),Integer.valueOf(body.get("quantity").toString()));
 }
 @PutMapping("/items/{productId}") public CartItem update(@PathVariable Long customerId,@PathVariable Long productId,@RequestBody Map<String,Integer> body){
  return service.update(customerId,productId,body.get("quantity"));
 }
 @DeleteMapping("/items/{productId}") @ResponseStatus(HttpStatus.NO_CONTENT)
 public void remove(@PathVariable Long customerId,@PathVariable Long productId){service.remove(customerId,productId);}
}
