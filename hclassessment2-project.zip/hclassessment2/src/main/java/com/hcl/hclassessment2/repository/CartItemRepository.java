package com.hcl.hclassessment2.repository;
import com.hcl.hclassessment2.entity.CartItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface CartItemRepository extends JpaRepository<CartItem, Long> { List<CartItem> findByCartCartId(Long cartId); Optional<CartItem> findByCartCartIdAndProductProductId(Long cartId, Long productId); }
