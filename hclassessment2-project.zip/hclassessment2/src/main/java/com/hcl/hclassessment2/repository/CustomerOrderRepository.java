package com.hcl.hclassessment2.repository;
import com.hcl.hclassessment2.entity.CustomerOrder;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> { List<CustomerOrder> findByCustomerCustomerIdOrderByOrderDateDesc(Long customerId); }
