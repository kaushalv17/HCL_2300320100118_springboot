package com.hcl.hclassessment2.service;
import com.hcl.hclassessment2.entity.*;
import com.hcl.hclassessment2.repository.*;
import com.hcl.hclassessment2.exception.ResourceNotFoundException;
import org.springframework.stereotype.Service; import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime; import java.util.*;
@Service
public class OrderService {
 private final CustomerRepository customers; private final CartRepository carts; private final CartItemRepository cartItems;
 private final ProductRepository products; private final CustomerOrderRepository orders;
 public OrderService(CustomerRepository customers,CartRepository carts,CartItemRepository cartItems,ProductRepository products,CustomerOrderRepository orders){
  this.customers=customers;this.carts=carts;this.cartItems=cartItems;this.products=products;this.orders=orders;
 }
 @Transactional
 public CustomerOrder place(Long customerId){
  Customer customer=customers.findById(customerId).orElseThrow(()->new ResourceNotFoundException("Customer not found"));
  Cart cart=carts.findByCustomerCustomerId(customerId).orElseThrow(()->new ResourceNotFoundException("Cart not found"));
  List<CartItem> selected=cartItems.findByCartCartId(cart.getCartId());
  if(selected.isEmpty())throw new IllegalArgumentException("Cart is empty");
  CustomerOrder order=new CustomerOrder();order.setCustomer(customer);order.setOrderDate(LocalDateTime.now());order.setOrderStatus("PLACED");
  List<OrderItem> snapshot=new ArrayList<>();double total=0.0;
  for(CartItem ci:selected){
   Product p=products.findById(ci.getProduct().getProductId()).orElseThrow(()->new ResourceNotFoundException("Product not found"));
   if(p.getQuantity()<ci.getQuantity())throw new IllegalArgumentException("Insufficient stock for "+p.getProductName());
   p.setQuantity(p.getQuantity()-ci.getQuantity());products.save(p);
   OrderItem oi=new OrderItem();oi.setCustomerOrder(order);oi.setProduct(p);oi.setQuantity(ci.getQuantity());oi.setPrice(p.getPrice());
   snapshot.add(oi);total+=p.getPrice()*ci.getQuantity();
  }
  order.setItems(snapshot);order.setTotalAmount(total);CustomerOrder saved=orders.save(order);cartItems.deleteAll(selected);return saved;
 }
 public List<CustomerOrder> history(Long customerId){
  if(!customers.existsById(customerId))throw new ResourceNotFoundException("Customer not found");
  return orders.findByCustomerCustomerIdOrderByOrderDateDesc(customerId);
 }
 public CustomerOrder one(Long id){return orders.findById(id).orElseThrow(()->new ResourceNotFoundException("Order not found: "+id));}
 @Transactional
 public CustomerOrder cancel(Long id){
  CustomerOrder order=one(id);
  if(!"PLACED".equalsIgnoreCase(order.getOrderStatus()))throw new IllegalArgumentException("Only placed orders can be cancelled");
  for(OrderItem oi:order.getItems()){
   Product p=products.findById(oi.getProduct().getProductId()).orElseThrow(()->new ResourceNotFoundException("Product not found"));
   p.setQuantity(p.getQuantity()+oi.getQuantity());products.save(p);
  }
  order.setOrderStatus("CANCELLED");return orders.save(order);
 }
}
