# hclassessment2 — Online Shopping Application

Spring Boot REST API built with Java 17, Spring Data JPA and MySQL.

## Project structure

```text
hclassessment2/
├── src/main/java/com/hcl/hclassessment2/
│   ├── Hclassessment2Application.java
│   ├── controller/
│   ├── entity/
│   ├── exception/
│   ├── repository/
│   └── service/
├── src/main/resources/application.properties
├── src/test/java/com/hcl/hclassessment2/
└── pom.xml
```

## Requirements
- JDK 17
- Maven 3.6+
- MySQL 8+

## Database
Create the database (or let the JDBC URL create it if the MySQL user has permission):

```sql
CREATE DATABASE online_shopping;
```

Update `src/main/resources/application.properties`. Defaults are MySQL username `root` and password `root`. Prefer environment variables:
- `DB_URL`
- `DB_USERNAME`
- `DB_PASSWORD`

## Run
From the folder containing `pom.xml`:

```bash
mvn clean spring-boot:run
```

Or run `Hclassessment2Application.java` in IntelliJ IDEA. Base URL: `http://localhost:8080`.

## API endpoints

### Customers
| Method | Endpoint |
|---|---|
| POST | `/api/customers` |
| GET | `/api/customers` |
| GET | `/api/customers/{id}` |
| PUT | `/api/customers/{id}` |
| DELETE | `/api/customers/{id}` |

Example:
```json
{"customerName":"Aarav Sharma","email":"aarav@example.com","password":"change-me","mobile":"9876543210","city":"Ghaziabad"}
```

### Products
| Method | Endpoint |
|---|---|
| POST | `/api/products` |
| GET | `/api/products` |
| GET | `/api/products/{id}` |
| PUT | `/api/products/{id}` |
| DELETE | `/api/products/{id}` |

Example:
```json
{"productName":"Wireless Mouse","description":"Bluetooth mouse","price":799.0,"quantity":25,"category":"Electronics"}
```

### Cart
| Method | Endpoint |
|---|---|
| GET | `/api/customers/{customerId}/cart` |
| GET | `/api/customers/{customerId}/cart/items` |
| POST | `/api/customers/{customerId}/cart/items` |
| PUT | `/api/customers/{customerId}/cart/items/{productId}` |
| DELETE | `/api/customers/{customerId}/cart/items/{productId}` |

POST body:
```json
{"productId":1,"quantity":2}
```
PUT body:
```json
{"quantity":3}
```

### Orders
| Method | Endpoint |
|---|---|
| POST | `/api/customers/{customerId}/orders` |
| GET | `/api/customers/{customerId}/orders` |
| GET | `/api/orders/{orderId}` |
| PUT | `/api/orders/{orderId}/cancel` |

Checkout checks stock, decreases inventory, calculates total amount and empties the cart. Cancelling a placed order restores inventory.

## Notes
- Uses the six required entities; no DTO, JWT or Spring Security classes.
- Password is stored as supplied to match the simple assessment scope. Never use plain-text password storage in a production application.
- `Double` is retained for price fields to match the supplied assessment schema; production financial applications should use `BigDecimal`.
