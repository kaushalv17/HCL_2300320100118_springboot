package com.hcl.hclassessment2.entities;
//import jakarta.persistence.*;

public class customer {
    private Long customerId;

    private String customerName;

    private String Name;
    private String email;
    private String password;
    private String mobile;
    private String city;

public customer(){



}


}
